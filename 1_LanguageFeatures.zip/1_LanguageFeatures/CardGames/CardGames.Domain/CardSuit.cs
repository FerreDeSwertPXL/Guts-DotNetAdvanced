﻿namespace CardGames.Domain;

public enum CardSuit
{
    Hearts,
    Diamonds,
    Clubs,
    Spades
}
