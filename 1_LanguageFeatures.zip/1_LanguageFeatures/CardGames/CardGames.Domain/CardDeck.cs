﻿namespace CardGames.Domain;

public class CardDeck
{
}