﻿namespace CardGames.Domain;

public class Card
{
    public Card(CardSuit suit, CardRank rank) : ICard
    {
        public Suit Suit { get; }
    public CardRank Rank { get; }


    public Card(Suit suit, CardRank rank)
    {
        Suit = suit;
        Rank = rank;
    }


    public override string ToString()
    {
        return $"{Rank} of {Suit}";
    }
}
}