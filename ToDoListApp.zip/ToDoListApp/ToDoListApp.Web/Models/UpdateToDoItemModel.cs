﻿namespace ToDoListApp.Web.Models;

public class UpdateToDoItemModel
{
    public bool IsDone { get; set; }
}