﻿using Microsoft.AspNetCore.Mvc;

namespace BethanysPieShop.Controllers
{
    public class ContactController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }
    }
}
