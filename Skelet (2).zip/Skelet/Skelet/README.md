# Oplossing voor `InvalidOperationException` in `HomeController`

## Probleem

De applicatie crashte bij het opstarten met de volgende foutmelding:

```
InvalidOperationException: Unable to resolve service for type 'Microsoft.Extensions.Logging.ILogger' while attempting to activate 'PokemonApp.Web.Controllers.HomeController'.
```

Dit betekent dat de `HomeController` een `ILogger`-object nodig heeft, maar het dependency injection-systeem was niet in staat om dit te voorzien.

## Oorzaak

De constructor van de `HomeController` vroeg om een non-generieke `ILogger`:

```csharp
public HomeController(IPokemonRepository pokemonRepository, ILogger logger)
{
    // ...
}
```

Het ASP.NET Core dependency injection-systeem is standaard geconfigureerd om specifieke, generieke `ILogger<T>`-instanties te verstrekken, waarbij `T` de klasse is die de logger aanvraagt. Het systeem wist dus niet hoe het een algemene `ILogger` moest aanmaken.

## Oplossing

De oplossing was om de constructor van `HomeController` aan te passen zodat deze de juiste generieke `ILogger<HomeController>` aanvraagt:

```csharp
// PokemonApp.Web/Controllers/HomeController.cs

using Microsoft.Extensions.Logging; // Namespace toegevoegd indien nodig

// ...

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(IPokemonRepository pokemonRepository, ILogger<HomeController> logger)
    {
        _pokemonRepository = pokemonRepository;
        _logger = logger;
    }

    // ...
}
```

Door `ILogger<HomeController>` te gebruiken, kan het dependency injection-systeem de correcte, voor deze controller bestemde, logger injecteren. Dit lost de `InvalidOperationException` op en laat de applicatie correct starten.
