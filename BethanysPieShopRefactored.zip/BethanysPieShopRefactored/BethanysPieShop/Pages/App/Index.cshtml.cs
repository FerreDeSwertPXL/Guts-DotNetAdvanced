using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BethanysPieShop.Pages.App
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
