﻿using BethanysPieShop.Models;

namespace BethanysPieShop.ViewModels
{
    public class PieListViewModel
    {
        public string Category { get; }
        public IEnumerable<Pie> Pies { get; }

        public PieListViewModel(string category, IEnumerable<Pie> pies)
        {
            Category = category;
            Pies = pies;
        }
    }
}
