﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BethanysPieShop.Models
{
    public class BethanysPieShopDbContext : IdentityDbContext<IdentityUser>

    {
    public DbSet<Pie> Pies { get; set; }
    public DbSet<Category> Categories { get; set; }

    public DbSet<ShoppingCartItem> ShoppingCartItems { get; set; }

    public DbSet<Order> Orders { get; set; }

    public BethanysPieShopDbContext(DbContextOptions options) : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OrderDetail>().ToTable("OrderDetails");

        base.OnModelCreating(modelBuilder);
    }
    }
}
