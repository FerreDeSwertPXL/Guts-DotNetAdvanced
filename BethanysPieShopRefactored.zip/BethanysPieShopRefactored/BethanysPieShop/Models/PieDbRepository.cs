﻿using Microsoft.EntityFrameworkCore;

namespace BethanysPieShop.Models;

public class PieDbRepository : IPieRepository
{
    private readonly BethanysPieShopDbContext _context;

    public PieDbRepository(BethanysPieShopDbContext context)
    {
        _context = context;
    }
    public async Task<IEnumerable<Pie>> GetAllAsync()
    {
        List<Pie> pies = await _context.Pies.Include(pie => pie.Category).ToListAsync();
        return pies;
    }

    public IEnumerable<Pie> GetPiesOfTheWeek()
    {
        return _context.Pies.Where(p => p.IsPieOfTheWeek).ToList();
    }

    public Pie? GetById(int id)
    {
        return _context.Pies.FirstOrDefault(p => p.PieId == id);
    }

    public IEnumerable<Pie> SearchPies(string searchQuery)
    {
        searchQuery = searchQuery.ToLower();
        return _context.Pies.Where(p => p.Name.ToLower().Contains(searchQuery) || (p.ShortDescription != null && p.ShortDescription.Contains(searchQuery)));
    }
}