﻿using LinqExamples.Models;

namespace LinqExamples;

public class GroupExamples
{
    public IList<IGrouping<int, int>> GroupEvenAndOddNumbers(int[] numbers)
    {
        var grouped = from number in numbers
                      group number by number % 2 into e
                      select e;

        return grouped.ToList();
    }

    public IList<PersonsOfSameBirthYearGroup> GroupPersonsByBirthYear(IList<Person> persons)
    {
        var groupPeople = from person in persons
                          group person by person.BirthDate.Year into g
                          select new PersonsOfSameBirthYearGroup
                          {
                                BirthYear = g.Key,
                                Persons = g
                          };

        return groupPeople.ToList();
    }
}