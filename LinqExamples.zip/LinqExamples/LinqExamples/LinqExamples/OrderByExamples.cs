﻿using LinqExamples.Models;

namespace LinqExamples;

public class OrderByExamples
{
    public double[] SortAnglesFromBigToSmall(double[] angles)
    {
        var sorted = from angle in angles
                     orderby angle descending
                     select angle;

        return sorted.ToArray();
    }

    public IList<Person> SortPersonsFromYoungToOldAndThenOnNameAlphabetically(List<Person> persons)
    {
        var sortedpeople = from person in persons
                           orderby person.BirthDate
                           orderby person.Name
                           select person;

        return sortedpeople.ToList();
    }
}