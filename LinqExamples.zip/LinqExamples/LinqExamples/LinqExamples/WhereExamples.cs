﻿using LinqExamples.Models;

namespace LinqExamples;

public class WhereExamples
{
    public int[] FilterOutNumbersDivisibleByTen(int[] numbers)
    {
        var divisbleByTen = from number in numbers
                            where number % 10 == 0
                            select number;

        return divisbleByTen.ToArray();
    }

    public IList<Person> FilterOutPersonsThatAreEighteenOrOlder(List<Person> persons)
    {
        var eighteenOrOlder = from person in persons
                              where person.BirthDate <= DateTime.Now.AddYears(-18)
                              select person;

        return eighteenOrOlder.ToList();
    }
}