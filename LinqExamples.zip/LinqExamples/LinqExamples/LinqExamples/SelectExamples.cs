﻿using LinqExamples.Models;

namespace LinqExamples
{
    public class SelectExamples
    {
        public IList<int> GetLengthOfWords(IEnumerable<string?> words)
        {
            var wordQuary = from word in words
                            select word?.Length ?? 0;
            return wordQuary.ToList();
        }

        public IList<AngleInfo> ConvertAnglesToAngleInfos(IEnumerable<double> anglesInDegrees)
        {
            var angleQuary = from angle in anglesInDegrees
                             select new AngleInfo { Angle = angle, Cosinus = Math.Cos(angle * Math.PI / 180), Sinus = Math.Sin(angle * Math.PI / 180) };

            return angleQuary.ToList();
        }
    }
}