﻿using LinqExamples.Models;

namespace LinqExamples;

public class JoinExamples
{
    public int[] GetEvenNumbersOfIntersection(int[] firstList, int[] secondList)
    {
        var evenNumbers = from first in firstList
                          join second in secondList on first equals second
                          where first % 2 == 0
                          select first;

        return evenNumbers.ToArray();
    }

    public IList<string> MatchPersonsOnBirthMonth(IList<Person> group1, IList<Person> group2)
    {
        var matchedCouples = from person1 in group1
                             join person2 in group2
                             on person1.BirthDate.Month equals person2.BirthDate.Month
                             select $"{person1.Name} and {person2.Name}";

        return matchedCouples.ToList();
    }
}