﻿using System;
using System.Drawing;

namespace BalloonFun.Console
{
    public static class RandomExtensions
    {
        public static Balloon NextBalloon(this Random random, int maxSize)
        {
            var color = GenerateRandomColor(random);  
            var size = random.Next(1, maxSize + 1);   
            return new Balloon(color, size);          
        }

        public static Balloon NextBalloonFromArray(this Random random, Balloon[] balloons)
        {
            if (balloons == null || balloons.Length == 0)
                throw new ArgumentException("Balloon array cannot be null or empty", nameof(balloons));

            int index = random.Next(balloons.Length);  
            return balloons[index];                    
        }

        private static Color GenerateRandomColor(Random random)
        {
            int red = random.Next(0, 256);    
            int green = random.Next(0, 256);  
            int blue = random.Next(0, 256);   
            return Color.FromArgb(red, green, blue);  
        }
    }
}
