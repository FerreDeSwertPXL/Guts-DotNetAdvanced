﻿using System;
namespace BalloonFun.Console;

public interface IOutputWriter
{
    void Write(string message);
}