﻿using System.Drawing;

namespace BalloonFun.Console;

public struct Balloon
{
    public Color Color { get; }
    public int Size { get; }

    private string _name;
    public string Name 
    { 
        get => _name;
        set => _name = value; 
    }

    public Balloon(Color color, int size)
    {
        Color = color;
        Size = size;
        _name = null;
    }

    /// <summary>
    /// Personalizes the balloon by giving it a name.
    /// </summary>
    public void Baptize(string name)
    {
        Name = name;
    }
}